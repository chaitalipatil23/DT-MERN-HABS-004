const jwt = require('jsonwebtoken');
const User = require('../models/User');

const auth = async (req,res,next) => {
    const token = req.header('Authorization')?.replace('Bearer ','');
    if(!token) return res.status(401).json({msg:'No token,auth denied'});
    
    try {
        const decoded = jwt.verify(token,process.env.JWT_SECRET);
        req.user = await User.findById(decoded.id).select('-password');
        if (!req.user) return res.status(401).json({msg:'User not found'});
        next();

    } catch (err) {
        res.status(401).json({msg:'Token invalid'});
    }
};

const permit = (...allowedRoles) => {
    return (req,res,next) => {
        if (!req.user) return res.status(401).json({msg:'Unauthenticated'});
        if(!allowedRoles.includes(req.user.role)) {
            return res.status(403).json({msg:'Forbidden: insufficient rights'});
        }
        next();
    };
};

module.exports = {auth,permit};