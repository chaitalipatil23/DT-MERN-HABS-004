const mongoose = require('mongoose');

const apptSchema = new mongoose.Schema({
    doctor: {type:mongoose.Schema.Types.ObjectId,ref:'Doctor',required:true},
    patient: {type:mongoose.Schema.Types.ObjectId,ref:'User',required:true},
    date:{type: String,required:true},
    time:{type: String,required:true},
    status:{type: String,enum:['Booked','Completed','Cancelled'],default:'Booked' },
    notes:String
},{timestamps:true});

apptSchema.index({ doctor:1,date:1,time:1},{unique:true});

module.exports = mongoose.model('Appointment',apptSchema);
