const mongoose = require('mongoose');

const availabilitySchema = new mongoose.Schema({
    day:String,
    slots:[{start:String,end:String}]
});

const doctorSchema = new mongoose.Schema({
    user: {type: mongoose.Schema.Types.ObjectId,ref:'User',required:true},
    specialization:String,
    experience:String,
    availability: [availabilitySchema],
    bio:String
}, {timestamps:true});


module.exports = mongoose.model('Doctor',doctorSchema);
