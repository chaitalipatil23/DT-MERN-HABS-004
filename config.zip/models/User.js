const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    name:{type: String,required:true},
    email:{type: String,required:true,unique:true},
    password:{type: String,required:true},
    role:{type: String, enum:['admin','doctor','patient'],default:'patient'},
    phone:String,
    doctorProfile:{ type:mongoose.Schema.Types.ObjectId,ref:'Doctor'}
}, {timestamps:true});

module.exports = mongoose.model('User',userSchema);
