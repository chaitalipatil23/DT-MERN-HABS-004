const express = require('express');
const router = express.Router();
const Appointment = require('../models/Appointment');
const Doctor = require('../models/Doctor');
const { auth, permit } = require('../middleware/auth');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const uploadDir = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);
const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, uploadDir),
  filename: (_, file, cb) => cb(null, Date.now() + '-' + file.originalname.replace(/\s+/g,''))
});
const upload = multer({ storage });

router.post('/book', auth, permit('patient'), async (req,res) => {
  try {
    const { doctorId, date, time } = req.body;
    
    // Find doctor by user ID or doctor ID
    let doctorDoc = await Doctor.findOne({ user: doctorId });
    if (!doctorDoc) {
      doctorDoc = await Doctor.findById(doctorId);
    }
    if (!doctorDoc) {
      return res.status(404).json({ msg: 'Doctor not found' });
    }

    // Check if slot is already booked
    const exists = await Appointment.findOne({ 
      doctor: doctorDoc._id, 
      date, 
      time, 
      status: { $nin: ['Cancelled'] } 
    });
    if (exists) return res.status(400).json({ msg: 'Slot already booked' });

    const appt = new Appointment({
      patient: req.user._id,
      doctor: doctorDoc._id,
      date, 
      time
    });
    await appt.save();
    res.json({ msg: 'Appointment booked', appointment: appt });
  } catch (err) {
    console.error(err); 
    res.status(500).json({ msg: 'Server error' });
  }
});

router.get('/patient', auth, permit('patient'), async (req,res) => {
  try {
    const list = await Appointment.find({ patient: req.user._id })
      .populate({
        path: 'doctor',
        populate: { path: 'user', select: 'name email' }
      })
      .sort({ date: -1 });
    res.json(list);
  } catch (err) { 
    console.error(err); 
    res.status(500).json({ msg: 'Server error' }); 
  }
});

router.get('/doctor', auth, permit('doctor'), async (req,res) => {
  try {
    // Find doctor profile for this user
    const doctorDoc = await Doctor.findOne({ user: req.user._id });
    if (!doctorDoc) {
      return res.json([]);
    }
    const list = await Appointment.find({ doctor: doctorDoc._id })
      .populate('patient', 'name email')
      .populate('doctor')
      .sort({ date: 1 });
    res.json(list);
  } catch (err) { 
    console.error(err); 
    res.status(500).json({ msg: 'Server error' }); 
  }
});

router.post('/:id/prescribe', auth, permit('doctor'), upload.single('prescription'), async (req,res) => {
  try {
    const appt = await Appointment.findById(req.params.id);
    if (!appt) return res.status(404).json({ msg: 'Appointment not found' });

    // Find doctor profile for this user
    const doctorDoc = await Doctor.findOne({ user: req.user._id });
    if (!doctorDoc || appt.doctor.toString() !== doctorDoc._id.toString()) {
      return res.status(403).json({ msg: 'Not allowed' });
    }

    if (req.file) appt.prescriptionFile = '/uploads/' + path.basename(req.file.path);
    appt.status = 'Completed';
    appt.notes = req.body.notes || appt.notes;
    await appt.save();
    res.json({ msg: 'Prescription uploaded', appointment: appt });
  } catch (err) {
    console.error(err); 
    res.status(500).json({ msg: 'Server error' });
  }
});

module.exports = router;