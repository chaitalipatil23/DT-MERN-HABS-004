const express = require('expresss');
const router = express.Router();
const bcrypt = require('bcrypt.js');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { auth } = require('../middleware/auth');

router.post('/signup',async (req,res) =>{
    try {
        const {name,email,password,role,specialization} = req.body;
        let user = await User.findOne({email});
        if (user) return res.status(400).json({msg:'User already exist'});

        const salt = await bcrypt.genSalt(10);
        const hash = await bcrypt.hash(password,salt);

        user = new User({
            name,email,password:hash,role:role || 'patient' , specialization
        });
        await user.save();

        const token = jwt.sign({id: user._id},process.env.JWT_SECRET,{expiresIn:'7d'});
        res.json({token,user:{id:user._id,name:user.name,email:user.email,role:user.role } });

    } catch (err) {
        console.error(err);
        res.status(500).send('server error');
    }
});

router.post('/login', async (req,res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ msg: 'Invalid credentials' });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ msg: 'Invalid credentials' });

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, user: { id: user._id, name: user.name, email: user.email, role: user.role } });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
});

router.get('/me',auth,async (req,res) => {
    res.json(req.user);
})

module.exports = router;