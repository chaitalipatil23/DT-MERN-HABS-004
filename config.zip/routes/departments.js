const express = require('express');
const router = express.Router();
const Department = require('../models/Department');
const { auth, permit } = require('../middleware/auth');

router.post('/add', auth, permit('admin'), async (req,res) => {
  try {
    const { name, description } = req.body;
    const d = new Department({ name, description });
    await d.save();
    res.json(d);
  } catch (err) {
    console.error(err); res.status(500).send('Server error');
  }
});

router.get('/', async (req,res) => {
  try {
    const list = await Department.find().sort({ name: 1 });
    res.json(list);
  } catch (err) { console.error(err); res.status(500).send('Server error'); }
});

module.exports = router;