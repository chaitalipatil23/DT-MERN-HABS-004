const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Doctor = require('../models/Doctor');
const { auth,permit } = require('../middleware/auth');

router.post('/add',auth,permit('admin'),async(req,res) => {
    try {
        const { name,email,password='doctor123',specialization,experience}=req.body;
        let existing = await User.findOne({ email });
        if (existing) return res.status(400).json({ msg: 'Email exists' });

        const bcrypt = require('bcryptjs');
        const salt = await bcrypt.genSalt(10);
        const hash = await bcrypt.hash(password,salt);
        const user = new User({name,email,password:hash,role:'doctor',specialization});
        await user.save();

        const doctor = new Doctor({user:user._id,specialization,experience,availableSlots:[]});
        await doctor.save();

        res.json({msg: 'Doctor added', doctor});
    } catch (error) {
        console.error(error); res.status(500).send('Server error')
    }
});
router.get('/', async (req, res) => {
  try {
    const doctors = await Doctor.find().populate('user', 'name email');
    res.json(doctors);
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
});

router.put('/:doctorId/slots', auth, permit('doctor'), async (req,res) => {
  try {
    const { doctorId } = req.params;
    const { slots } = req.body; 
    const doctor = await Doctor.findById(doctorId);
    if (!doctor) return res.status(404).json({ msg: 'Doctor not found' });

    if (doctor.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ msg: 'Not allowed to edit slots for this doctor' });
    }
    doctor.availableSlots = slots;
    await doctor.save();
    res.json(doctor);
  } catch (err) {
    console.error(err); res.status(500).send('Server error');
  }
});

module.exports = router;