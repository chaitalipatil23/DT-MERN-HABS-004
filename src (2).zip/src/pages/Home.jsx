import React, { useState } from "react";
import { Link } from "react-router-dom";

function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white">
      <nav className="bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-700 shadow-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex items-center">
              <Link to="/" className="flex items-center">
                <div className="bg-white text-blue-600 px-4 py-2 rounded-xl font-bold text-xl mr-3 shadow-lg">
                  H
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-white">HABS</h1>
                  <p className="text-xs text-blue-100">Hospital Appointment System</p>
                </div>
              </Link>
            </div>
            
            <div className="hidden md:flex items-center space-x-1">
              <Link to="/" className="px-4 py-2 text-white hover:text-blue-100 hover:bg-white/10 rounded-lg font-medium transition-all duration-200">
                Home
              </Link>
              <a href="#features" className="px-4 py-2 text-white hover:text-blue-100 hover:bg-white/10 rounded-lg font-medium transition-all duration-200">
                Features
              </a>
              <a href="#how-it-works" className="px-4 py-2 text-white hover:text-blue-100 hover:bg-white/10 rounded-lg font-medium transition-all duration-200">
                How It Works
              </a>
              <a href="#about" className="px-4 py-2 text-white hover:text-blue-100 hover:bg-white/10 rounded-lg font-medium transition-all duration-200">
                About
              </a>
              <Link to="/login" className="px-4 py-2 text-white hover:text-blue-100 hover:bg-white/10 rounded-lg font-medium transition-all duration-200">
                Login
              </Link>
              <Link to="/signup" className="ml-4 px-6 py-2.5 bg-white text-blue-600 rounded-lg hover:bg-blue-50 font-semibold transition-all duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5">
                Get Started
              </Link>
            </div>
            
            <div className="md:hidden">
              <button 
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="text-white px-3 py-2 rounded-lg hover:bg-white/10 transition-colors font-medium"
              >
                {mobileMenuOpen ? 'Close' : 'Menu'}
              </button>
            </div>
          </div>
          
          {mobileMenuOpen && (
            <div className="md:hidden py-4 border-t border-blue-500">
              <div className="flex flex-col space-y-2">
                <Link to="/" className="px-4 py-2 text-white hover:text-blue-100 hover:bg-white/10 rounded-lg font-medium transition-colors" onClick={() => setMobileMenuOpen(false)}>
                  Home
                </Link>
                <a href="#features" className="px-4 py-2 text-white hover:text-blue-100 hover:bg-white/10 rounded-lg font-medium transition-colors" onClick={() => setMobileMenuOpen(false)}>
                  Features
                </a>
                <a href="#how-it-works" className="px-4 py-2 text-white hover:text-blue-100 hover:bg-white/10 rounded-lg font-medium transition-colors" onClick={() => setMobileMenuOpen(false)}>
                  How It Works
                </a>
                <a href="#about" className="px-4 py-2 text-white hover:text-blue-100 hover:bg-white/10 rounded-lg font-medium transition-colors" onClick={() => setMobileMenuOpen(false)}>
                  About
                </a>
                <Link to="/login" className="px-4 py-2 text-white hover:text-blue-100 hover:bg-white/10 rounded-lg font-medium transition-colors" onClick={() => setMobileMenuOpen(false)}>
                  Login
                </Link>
                <Link to="/signup" className="mx-4 mt-2 px-6 py-2.5 bg-white text-blue-600 rounded-lg hover:bg-blue-50 font-semibold transition-all duration-200 text-center shadow-lg" onClick={() => setMobileMenuOpen(false)}>
                  Get Started
                </Link>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-50 via-white to-indigo-50 overflow-hidden">
        <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-32">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="relative z-10">
              <div className="inline-block mb-4">
                <span className="px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-semibold">
                  🏥 Trusted by 10,000+ Patients
                </span>
              </div>
              <h1 className="text-5xl lg:text-6xl font-extrabold text-gray-900 leading-tight mb-6">
                Book Your Doctor
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">
                  Appointment Online
                </span>
              </h1>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                Experience seamless healthcare management. Connect with qualified doctors, 
                schedule appointments instantly, and manage your medical records all in one place.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <Link
                  to="/signup"
                  className="group px-8 py-4 bg-blue-600 text-white rounded-xl font-semibold text-lg shadow-xl hover:bg-blue-700 transition-all duration-300 transform hover:scale-105 hover:shadow-2xl flex items-center justify-center"
                >
                  Start Free Trial
                </Link>
                <Link
                  to="/login"
                  className="px-8 py-4 border-2 border-gray-300 text-gray-700 rounded-xl font-semibold text-lg hover:border-blue-600 hover:text-blue-600 transition-all duration-300 flex items-center justify-center"
                >
                  Sign In
                </Link>
              </div>
              <div className="flex items-center space-x-6 text-sm text-gray-600">
                <div className="flex items-center">
                  <span>Free Forever</span>
                </div>
                <div className="flex items-center">
                  <span>Secure & HIPAA Compliant</span>
                </div>
                <div className="flex items-center">
                  <span>24/7 Support</span>
                </div>
              </div>
            </div>

            {/* Right Image/Illustration */}
            <div className="relative lg:block hidden">
              <div className="relative z-10">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-indigo-400 rounded-3xl transform rotate-6 opacity-20 blur-3xl"></div>
                <div className="relative bg-white rounded-3xl shadow-2xl p-8 transform hover:scale-105 transition-transform duration-300">
                  <img
                    src="https://cdn-icons-png.flaticon.com/512/3875/3875433.png"
                    alt="Healthcare illustration"
                    className="w-full h-auto"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white border-y border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-600 mb-2">10K+</div>
              <div className="text-gray-600">Active Patients</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-600 mb-2">500+</div>
              <div className="text-gray-600">Expert Doctors</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-600 mb-2">50K+</div>
              <div className="text-gray-600">Appointments</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-600 mb-2">99%</div>
              <div className="text-gray-600">Satisfaction Rate</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 bg-gradient-to-b from-white to-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
              Everything You Need for
              <span className="block text-blue-600">Better Healthcare</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Comprehensive features designed to make healthcare management simple and efficient
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="group bg-white p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100">
              <h3 className="text-2xl font-bold text-gray-900 mb-3">Instant Booking</h3>
              <p className="text-gray-600 leading-relaxed">
                Book appointments with verified doctors in seconds. No phone calls, no waiting in queues. 
                Select your preferred time slot and get instant confirmation.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="group bg-white p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100">
              <h3 className="text-2xl font-bold text-gray-900 mb-3">Digital Prescriptions</h3>
              <p className="text-gray-600 leading-relaxed">
                Receive and store digital prescriptions securely. Access your medical records anytime, 
                anywhere. Share prescriptions with pharmacies instantly.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="group bg-white p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100">
              <h3 className="text-2xl font-bold text-gray-900 mb-3">Smart Dashboard</h3>
              <p className="text-gray-600 leading-relaxed">
                Personalized dashboards for patients and doctors. Track appointments, view medical history, 
                and manage everything from one central location.
              </p>
            </div>

            {/* Feature 4 */}
            <div className="group bg-white p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100">
              <h3 className="text-2xl font-bold text-gray-900 mb-3">Real-time Notifications</h3>
              <p className="text-gray-600 leading-relaxed">
                Get instant notifications for appointment confirmations, reminders, and updates. 
                Never miss an appointment with smart alerts.
              </p>
            </div>

            {/* Feature 5 */}
            <div className="group bg-white p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100">
              <h3 className="text-2xl font-bold text-gray-900 mb-3">Secure & Private</h3>
              <p className="text-gray-600 leading-relaxed">
                Your medical data is encrypted and secure. HIPAA compliant with industry-standard 
                security measures to protect your privacy.
              </p>
            </div>

            {/* Feature 6 */}
            <div className="group bg-white p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100">
              <h3 className="text-2xl font-bold text-gray-900 mb-3">Expert Doctors</h3>
              <p className="text-gray-600 leading-relaxed">
                Connect with verified, experienced doctors across various specialties. 
                Read reviews and choose the best healthcare provider for your needs.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4">How It Works</h2>
            <p className="text-xl text-gray-600">Get started in three simple steps</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="text-center relative">
              <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                <div className="bg-blue-600 text-white w-10 h-10 rounded-full flex items-center justify-center text-lg font-bold shadow-lg">
                  1
                </div>
              </div>
              <div className="bg-gradient-to-br from-blue-50 to-white p-8 pt-12 rounded-2xl shadow-lg border border-gray-100">
                <h3 className="text-2xl font-bold text-gray-900 mb-3">Create Account</h3>
                <p className="text-gray-600 leading-relaxed">
                  Sign up as a patient or doctor. Complete your profile in less than 2 minutes.
                </p>
              </div>
            </div>

            <div className="text-center relative">
              <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                <div className="bg-blue-600 text-white w-10 h-10 rounded-full flex items-center justify-center text-lg font-bold shadow-lg">
                  2
                </div>
              </div>
              <div className="bg-gradient-to-br from-blue-50 to-white p-8 pt-12 rounded-2xl shadow-lg border border-gray-100">
                <h3 className="text-2xl font-bold text-gray-900 mb-3">Book Appointment</h3>
                <p className="text-gray-600 leading-relaxed">
                  Browse available doctors, select your preferred date and time slot.
                </p>
              </div>
            </div>

            <div className="text-center relative">
              <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                <div className="bg-blue-600 text-white w-10 h-10 rounded-full flex items-center justify-center text-lg font-bold shadow-lg">
                  3
                </div>
              </div>
              <div className="bg-gradient-to-br from-blue-50 to-white p-8 pt-12 rounded-2xl shadow-lg border border-gray-100">
                <h3 className="text-2xl font-bold text-gray-900 mb-3">Get Treatment</h3>
                <p className="text-gray-600 leading-relaxed">
                  Visit your doctor and receive digital prescriptions instantly.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-700 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid-pattern opacity-10"></div>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6">
            Ready to Transform Your Healthcare Experience?
          </h2>
          <p className="text-xl text-blue-100 mb-10 max-w-2xl mx-auto">
            Join thousands of patients and doctors who trust HABS for seamless healthcare management
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/signup"
              className="px-10 py-4 bg-white text-blue-600 rounded-xl font-bold text-lg shadow-2xl hover:bg-gray-100 transition-all duration-300 transform hover:scale-105"
            >
              Start Free Today
            </Link>
            <Link
              to="/login"
              className="px-10 py-4 border-2 border-white text-white rounded-xl font-bold text-lg hover:bg-white/10 transition-all duration-300"
            >
              Sign In
            </Link>
          </div>
        </div>
      </section>

      <section id="about" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4">About HABS</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              HABS is a comprehensive healthcare management platform designed to bridge the gap between patients and healthcare providers. 
              We are committed to making healthcare more accessible, efficient, and patient-centered.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6">
              <h3 className="text-2xl font-bold text-gray-900 mb-3">Our Mission</h3>
              <p className="text-gray-600">
                To revolutionize healthcare delivery by providing innovative digital solutions that connect patients with quality healthcare services.
              </p>
            </div>
            <div className="text-center p-6">
              <h3 className="text-2xl font-bold text-gray-900 mb-3">Our Vision</h3>
              <p className="text-gray-600">
                To become the leading platform for healthcare management, empowering millions of patients and healthcare providers worldwide.
              </p>
            </div>
            <div className="text-center p-6">
              <h3 className="text-2xl font-bold text-gray-900 mb-3">Our Values</h3>
              <p className="text-gray-600">
                Integrity, innovation, and patient-centricity drive everything we do. We believe in making healthcare accessible to all.
              </p>
            </div>
          </div>
        </div>
      </section>

      <footer className="bg-gradient-to-br from-gray-900 via-gray-800 to-indigo-900 text-gray-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
            <div>
              <div className="flex items-center mb-6">
                <div className="bg-gradient-to-br from-blue-500 to-indigo-600 text-white px-4 py-2 rounded-xl font-bold text-xl mr-3 shadow-lg">
                  H
                </div>
                <h3 className="text-2xl font-bold text-white">HABS</h3>
              </div>
              <p className="text-gray-300 leading-relaxed mb-6">
                Making healthcare accessible and convenient for everyone. Your trusted partner in health management.
              </p>
              <div className="flex space-x-3">
                <a href="#" className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg flex items-center justify-center text-white hover:from-blue-700 hover:to-blue-800 transition-all shadow-md hover:shadow-lg transform hover:-translate-y-0.5">
                  <span className="text-sm font-bold">f</span>
                </a>
                <a href="#" className="w-10 h-10 bg-gradient-to-br from-blue-400 to-blue-500 rounded-lg flex items-center justify-center text-white hover:from-blue-500 hover:to-blue-600 transition-all shadow-md hover:shadow-lg transform hover:-translate-y-0.5">
                  <span className="text-sm font-bold">t</span>
                </a>
                <a href="#" className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-indigo-700 rounded-lg flex items-center justify-center text-white hover:from-indigo-700 hover:to-indigo-800 transition-all shadow-md hover:shadow-lg transform hover:-translate-y-0.5">
                  <span className="text-sm font-bold">in</span>
                </a>
              </div>
            </div>
            
            <div>
              <h4 className="text-lg font-bold text-white mb-6">Product</h4>
              <ul className="space-y-3">
                <li>
                  <a href="#features" className="text-gray-300 hover:text-blue-400 transition-colors block">
                    Features
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-300 hover:text-blue-400 transition-colors block">
                    Pricing
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-300 hover:text-blue-400 transition-colors block">
                    Security
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-300 hover:text-blue-400 transition-colors block">
                    Updates
                  </a>
                </li>
                <li>
                  <Link to="/login" className="text-gray-300 hover:text-blue-400 transition-colors block">
                    Login
                  </Link>
                </li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-bold text-white mb-6">Company</h4>
              <ul className="space-y-3">
                <li>
                  <a href="#about" className="text-gray-300 hover:text-blue-400 transition-colors block">
                    About Us
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-300 hover:text-blue-400 transition-colors block">
                    Blog
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-300 hover:text-blue-400 transition-colors block">
                    Careers
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-300 hover:text-blue-400 transition-colors block">
                    Contact
                  </a>
                </li>
                <li>
                  <a href="#how-it-works" className="text-gray-300 hover:text-blue-400 transition-colors block">
                    How It Works
                  </a>
                </li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-bold text-white mb-6">Support</h4>
              <ul className="space-y-3">
                <li>
                  <a href="#" className="text-gray-300 hover:text-blue-400 transition-colors block">
                    Help Center
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-300 hover:text-blue-400 transition-colors block">
                    Documentation
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-300 hover:text-blue-400 transition-colors block">
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-300 hover:text-blue-400 transition-colors block">
                    Terms of Service
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-300 hover:text-blue-400 transition-colors block">
                    FAQ
                  </a>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-700 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
              <div className="flex flex-col md:flex-row items-center space-y-2 md:space-y-0 md:space-x-6 text-sm text-gray-400">
                <p>© {new Date().getFullYear()} HABS. All rights reserved.</p>
                <a href="#" className="hover:text-blue-400 transition-colors">Privacy</a>
                <a href="#" className="hover:text-blue-400 transition-colors">Terms</a>
                <a href="#" className="hover:text-blue-400 transition-colors">Cookies</a>
              </div>
              <div className="flex items-center space-x-2 text-sm text-gray-300">
                <span>Made with</span>
                <span className="text-red-500 text-lg">❤</span>
                <span>for better healthcare</span>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default Home;
