import { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate, Link } from "react-router-dom";

const PatientDashboard = () => {
  const [doctors, setDoctors] = useState([]);
  const [selectedDoctor, setSelectedDoctor] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(false);
  const [user, setUser] = useState(null);
  const [message, setMessage] = useState({ type: "", text: "" });

  const token = localStorage.getItem("token");
  const navigate = useNavigate();

  useEffect(() => {
    const userData = localStorage.getItem("user");
    if (userData) {
      setUser(JSON.parse(userData));
    }
    fetchDoctors();
    fetchAppointments();
  }, []);

  const fetchDoctors = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/doctors");
      setDoctors(res.data);
    } catch (err) {
      console.error("Error fetching doctors:", err);
    }
  };

  const fetchAppointments = async () => {
    if (!token) return;
    try {
      const res = await axios.get("http://localhost:5000/api/appointments/patient", {
        headers: { Authorization: `Bearer ${token}` }
      });
      setAppointments(res.data);
    } catch (err) {
      console.error("Error fetching appointments:", err);
    }
  };

  const bookAppointment = async () => {
    if (!selectedDoctor || !date || !time) {
      setMessage({ type: "error", text: "Please select doctor, date, and time" });
      setTimeout(() => setMessage({ type: "", text: "" }), 3000);
      return;
    }
    if (!token) {
      setMessage({ type: "error", text: "Please login first" });
      setTimeout(() => setMessage({ type: "", text: "" }), 3000);
      return;
    }
    setLoading(true);
    try {
      await axios.post("http://localhost:5000/api/appointments/book", {
        doctorId: selectedDoctor, date, time
      }, { headers: { Authorization: `Bearer ${token}` } });
      setMessage({ type: "success", text: "Appointment booked successfully!" });
      setSelectedDoctor("");
      setDate("");
      setTime("");
      fetchAppointments();
      setTimeout(() => setMessage({ type: "", text: "" }), 3000);
    } catch (err) {
      setMessage({ type: "error", text: err.response?.data?.msg || "Failed to book appointment" });
      setTimeout(() => setMessage({ type: "", text: "" }), 3000);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      <nav className="bg-white shadow-md sticky top-0 z-50 backdrop-blur-sm bg-white/95">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex items-center space-x-3">
              <Link to="/" className="flex items-center space-x-3">
                <div>
                  <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">HABS</h1>
                  <p className="text-xs text-gray-500">Patient Portal</p>
                </div>
              </Link>
            </div>
            <div className="flex items-center space-x-6">
              {user && (
                <div className="hidden md:flex items-center space-x-3 bg-blue-50 px-4 py-2 rounded-lg">
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-500 rounded-full flex items-center justify-center text-white font-semibold text-sm">
                    {user.name.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-900">{user.name}</p>
                    <p className="text-xs text-gray-500">Patient</p>
                  </div>
                </div>
              )}
              <button
                onClick={handleLogout}
                className="px-5 py-2.5 text-sm font-semibold text-white bg-gradient-to-r from-red-500 to-red-600 rounded-lg hover:from-red-600 hover:to-red-700 transition-all duration-200 shadow-md hover:shadow-lg transform hover:-translate-y-0.5"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {message.text && (
          <div className={`mb-6 p-4 rounded-xl shadow-lg ${
            message.type === "success" 
              ? "bg-green-50 border-l-4 border-green-500" 
              : "bg-red-50 border-l-4 border-red-500"
          }`}>
            <p className={`text-sm font-medium ${
              message.type === "success" ? "text-green-800" : "text-red-800"
            }`}>
              {message.text}
            </p>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
              <div className="flex items-center mb-6">
                <h2 className="text-3xl font-bold text-gray-900">Book New Appointment</h2>
              </div>
              
              <div className="space-y-6">
            <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Select Doctor
                  </label>
              <select
                value={selectedDoctor}
                onChange={(e) => setSelectedDoctor(e.target.value)}
                    className="w-full px-4 py-3.5 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all bg-white text-gray-900 font-medium"
              >
                <option value="">Choose a doctor</option>
                {doctors.map((doc) => (
                  <option key={doc._id} value={doc.user?._id || doc.user}>
                    {doc.user?.name || 'Unknown'} - {doc.specialization || 'N/A'}
                  </option>
                ))}
              </select>
            </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Date
                    </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
                      className="w-full px-4 py-3.5 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all text-gray-900 font-medium"
              />
            </div>
            <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Time
                    </label>
              <input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                      className="w-full px-4 py-3.5 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all text-gray-900 font-medium"
              />
            </div>
                </div>

              <button
                onClick={bookAppointment}
                disabled={loading}
                  className={`w-full px-6 py-4 rounded-xl text-white font-bold text-lg shadow-xl transition-all duration-200 transform ${
                  loading
                      ? "bg-gray-400 cursor-not-allowed"
                      : "bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 hover:shadow-2xl hover:-translate-y-0.5"
                  }`}
                >
                  {loading ? "Booking Appointment..." : "Book Appointment"}
              </button>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-gradient-to-br from-blue-600 to-indigo-600 rounded-2xl shadow-xl p-6 text-white">
              <div className="flex items-center mb-4">
                <h3 className="text-xl font-bold">Quick Tips</h3>
              </div>
              <ul className="space-y-3 text-sm">
                <li className="flex items-start">
                  <span className="mr-2">✓</span>
                  <span>Select your preferred doctor and time slot</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">✓</span>
                  <span>Book at least 24 hours in advance</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">✓</span>
                  <span>You'll receive a confirmation notification</span>
                </li>
              </ul>
            </div>

            <div className="bg-white rounded-2xl shadow-xl p-6 border border-gray-100">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Upcoming Appointments</h3>
              <div className="text-3xl font-bold text-blue-600 mb-2">
                {appointments.filter(a => new Date(a.date) >= new Date() && a.status !== 'Cancelled' && a.status !== 'Completed').length}
              </div>
              <p className="text-sm text-gray-600">Scheduled appointments</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <h2 className="text-3xl font-bold text-gray-900">My Appointments</h2>
            </div>
            <div className="text-sm text-gray-500">
              Total: {appointments.length}
            </div>
          </div>

          {appointments.length === 0 ? (
            <div className="text-center py-16">
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No appointments yet</h3>
              <p className="text-gray-600 mb-6">Get started by booking your first appointment above.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gradient-to-r from-gray-50 to-gray-100">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">Doctor</th>
                    <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">Date</th>
                    <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">Time</th>
                    <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">Status</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {appointments.map((appt) => (
                    <tr key={appt._id} className="hover:bg-blue-50 transition-colors duration-150">
                      <td className="px-6 py-5 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="w-10 h-10 bg-gradient-to-br from-blue-400 to-indigo-400 rounded-full flex items-center justify-center text-white font-semibold mr-3">
                            {(appt.doctor?.user?.name || appt.doctor?.name || 'D').charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <div className="text-sm font-semibold text-gray-900">
                          {appt.doctor?.user?.name || appt.doctor?.name || 'Unknown Doctor'}
                        </div>
                        <div className="text-sm text-gray-500">
                          {appt.doctor?.specialization || 'N/A'}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-5 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">
                          {new Date(appt.date).toLocaleDateString('en-US', { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' })}
                        </div>
                      </td>
                      <td className="px-6 py-5 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">
                        {appt.time}
                        </div>
                      </td>
                      <td className="px-6 py-5 whitespace-nowrap">
                        <span className={`px-3 py-1.5 inline-flex text-xs leading-5 font-bold rounded-full ${
                          appt.status === 'Completed' ? 'bg-green-100 text-green-800' :
                          appt.status === 'Cancelled' ? 'bg-red-100 text-red-800' :
                          'bg-blue-100 text-blue-800'
                        }`}>
                          {appt.status || 'Booked'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PatientDashboard;
